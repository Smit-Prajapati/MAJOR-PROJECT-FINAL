import React from 'react'
import CardUser from '../UserCard/CardUser'

const UserProfile = () => {
  return (
    <CardUser/>
  )
}

export default UserProfile